#!/usr/bin/env python3
"""Collect ARM64 systemd identity and standby evidence inside the isolated QEMU guest."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HOME = Path('/home/orangepi')
SERVICE = 'fc01-navigation.service'
EVIDENCE = Path('/root/position-step3-evidence')
ROLES = {
    'fc01_system_node', 'fc01_vision_node', 'fc01_target_interface_node',
    'mission', 'px4_state_bridge',
}
DDS_KEYS = {
    'ROS_DOMAIN_ID', 'ROS_LOCALHOST_ONLY', 'RMW_IMPLEMENTATION', 'ROS_DISCOVERY_SERVER',
    'ROS_STATIC_PEERS', 'CYCLONEDDS_URI', 'FASTRTPS_DEFAULT_PROFILES_FILE',
    'FASTDDS_DEFAULT_PROFILES_FILE', 'RMW_FASTRTPS_USE_QOS_FROM_XML',
    'ROS_AUTOMATIC_DISCOVERY_RANGE', 'ROS_SECURITY_ENABLE', 'ROS_SECURITY_STRATEGY',
    'ROS_SECURITY_KEYSTORE',
}
ROLE_NATIVE = 'fc01_system_node'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest() if hasattr(
            hashlib, 'file_digest') else digest_stream(stream)


def digest_stream(stream):
    result = hashlib.sha256()
    while chunk := stream.read(1024 * 1024):
        result.update(chunk)
    return result.hexdigest()


def output(name, result):
    (EVIDENCE / name).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')


def service():
    fields = 'ActiveState,SubState,MainPID,WorkingDirectory,ExecStart,ControlGroup,DropInPaths'
    out = subprocess.check_output(['systemctl', 'show', SERVICE, '-p', fields], text=True)
    return dict(line.split('=', 1) for line in out.splitlines() if '=' in line)


def proc_rows():
    rows = []
    for root in Path('/proc').glob('[0-9]*'):
        try:
            argv = [part.decode(errors='replace') for part in
                    (root / 'cmdline').read_bytes().split(b'\0') if part]
            names = [Path(item).name for item in argv[:2]]
            role = next((name for name in names if name in ROLES), None)
            if not role:
                continue
            stat = (root / 'stat').read_text().rsplit(')', 1)[1].split()
            if stat[0] == 'Z':
                continue
            rows.append(dict(pid=int(root.name), ppid=int(stat[1]), start_ticks=int(stat[19]),
                             role=role, argv=argv[:3], exe=os.readlink(root / 'exe'),
                             cgroup=(root / 'cgroup').read_text().strip()))
        except (FileNotFoundError, ProcessLookupError):
            continue
    return sorted(rows, key=lambda row: row['pid'])


def one_native(rows):
    natives = [row for row in rows if row['role'] == ROLE_NATIVE]
    assert len(natives) == 1, natives
    return natives[0]


def process_environment(pid):
    text = (Path('/proc') / str(pid) / 'environ').read_bytes().decode()
    rows = dict(row.split('=', 1) for row in text.split('\0') if '=' in row)
    return {key: rows[key] for key in sorted(DDS_KEYS & rows.keys())}


def read_json(path):
    return json.loads(path.read_bytes())


def snapshot(label, entry, mode):
    import yaml
    entry = HOME / 'FC01_versions' / entry
    runtime = entry / 'deployment/runtime.yaml'
    params = yaml.safe_load(runtime.read_text())['fc01_system']['ros__parameters']
    manifest = read_json(entry / 'ARM64_RELEASE.json')
    binary = entry / manifest['controller_relative']
    target_hash = manifest['payload_sha256'][manifest['controller_relative']]
    assert digest(binary) == target_hash
    expected_count = 5 if mode == 'position-track' else 1
    begin = time.monotonic()
    deadline = begin + 620
    last_progress = begin
    status_path = HOME / 'FC01_navigation/status.json'
    while True:
        info = service()
        procs = proc_rows()
        if info['ActiveState'] == 'active' and len(procs) == expected_count:
            native = one_native(procs)
            if status_path.is_file():
                row = read_json(status_path)
                state = row.get('state') or {}
                fields = ('status', 'land', 'local', 'attitude', 'flags', 'battery')
                source_counts = {field: state.get('source_timing', {}).get(field, {}).get('callbacks_total')
                                 for field in fields}
                stamp = state.get('diagnostic_monotonic_s')
                if (row.get('controller_pid') == native['pid'] and
                        row.get('supervisor_pid') == int(info['MainPID']) and
                        row.get('boot_id') == Path('/proc/sys/kernel/random/boot_id').read_text().strip() and
                        type(stamp) in (int, float) and 0 <= time.monotonic() - stamp < 3 and
                        all(value == 0 for value in source_counts.values())):
                    break
        assert time.monotonic() < deadline, (info, procs)
        if time.monotonic() - last_progress >= 30:
            print('ARM64_STANDBY_WAIT', label, round(time.monotonic() - begin),
                  info['ActiveState'], [process['role'] for process in procs], flush=True)
            last_progress = time.monotonic()
        time.sleep(.5)
    assert info['WorkingDirectory'] == str(entry) and str(entry / 'prebuilt_boot.sh') in info['ExecStart'], info
    assert Path(native['exe']) == binary and digest(Path('/proc') / str(native['pid']) / 'exe') == target_hash
    assert all(info['ControlGroup'] in process['cgroup'] for process in procs), procs
    assert params['rc_target_height'] == 1.5
    assert state.get('px4_takeoff_position_hold', False) == mode.startswith('position')
    assert state.get('px4_position_mission_enabled', False) == (mode == 'position-track')
    assert state.get('armed') is not True and state.get('active') is not True, state
    assert state.get('phase') == 'IDLE', state.get('phase')
    assert state.get('navigation_allowed') is not True and state.get('position_mission_motion') is not True
    assert row.get('feedback_current') is not True and row.get('status') != 'READY_WAIT_ARM'
    role_entries = {process['role']: process for process in procs}
    assert set(role_entries) == (ROLES if mode == 'position-track' else {ROLE_NATIVE}), role_entries
    if mode == 'position-track':
        for process in procs:
            assert any(arg.startswith(str(entry / 'install') + '/') for arg in process['argv']), process
    runtime_status = entry / 'deployment/vision-runtime.json'
    if runtime_status.is_file():
        while True:
            vision = read_json(runtime_status)
            current = (vision.get('supervisor_pid') == int(info['MainPID'])
                       and vision.get('mode') == mode)
            assert current, vision
            if mode != 'position-track':
                assert vision.get('enabled') is not True and vision.get('mission_control_enabled') is not True, vision
                break
            assert vision.get('calibration_state') == 'confirmed' and vision.get('mission_control_enabled') is True, vision
            source = vision.get('observations') or {}
            cam = source.get('camera', {}).get('value')
            mission = source.get('mission', {}).get('value')
            if isinstance(cam, dict) and isinstance(mission, dict):
                assert cam.get('ready') is False, cam
                assert mission.get('target_locked') is False and mission.get('native_navigation_current') is False, mission
                assert mission.get('control_authority') is not True, mission
                break
            assert time.monotonic() < deadline, vision
            time.sleep(.5)
    else:
        vision = None
        assert mode != 'position-track'
    result = dict(label=label, mode=mode, service=info, processes=procs,
                  controller_sha256=target_hash, runtime_sha256=digest(runtime), runtime=params,
                  source_commit=manifest['source_commit'],
                  config_source_path=params.get('fc01_config_source_path'),
                  environment=process_environment(native['pid']),
                  status=row.get('status'), reason=state.get('reason'), phase=state.get('phase'),
                  aircraft_feedback_current=row.get('feedback_current'),
                  navigation_allowed=state.get('navigation_allowed'),
                  no_flight_input_callbacks=source_counts, vision=vision,
                  snapshot_monotonic=time.monotonic(),
                  snapshot_wait_seconds=time.monotonic()-begin)
    output(label + '.json', result)
    print('ARM64_SYSTEMD_STANDBY_PASS', label, info['MainPID'], native['pid'], mode, result['reason'], flush=True)


def monitor():
    stop = False

    def on_stop(*_):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, on_stop)
    with (EVIDENCE / 'process-events.jsonl').open('w', buffering=1) as stream:
        previous = None
        while not stop:
            rows = proc_rows()
            if rows != previous:
                stream.write(json.dumps(dict(monotonic=time.monotonic(), processes=rows)) + '\n')
                previous = rows
            time.sleep(.25)


def check_transition():
    lines = (EVIDENCE / 'process-events.jsonl').read_text().splitlines()
    events = [json.loads(line) for line in lines if line]
    natives = []
    for event in events:
        matches = [item for item in event['processes'] if item['role'] == ROLE_NATIVE]
        assert len(matches) <= 1, event
        identity = [(p['pid'], p['start_ticks'], p['exe']) for p in matches]
        if not natives or natives[-1]['identity'] != identity:
            natives.append(dict(monotonic=event['monotonic'], identity=identity))
    assert len(natives) >= 5, natives
    assert all(not (a['identity'] and b['identity']) for a, b in zip(natives, natives[1:])), natives
    output('transition-result.json', dict(sample_interval_s=.25, sampled_no_overlap=True,
                                         empty_interval_between_each_observed_switch=True,
                                         displayed_native_transitions=natives))
    print('ARM64_OBSERVED_STOP_BEFORE_START_PASS', len(natives), flush=True)


def compare(a, b, check):
    before, after = (read_json(EVIDENCE / (x + '.json')) for x in (a, b))
    assert before['environment'] == after['environment']
    assert before['config_source_path'] == str(Path(before['service']['WorkingDirectory']) / 'deployment/runtime.yaml')
    assert after['config_source_path'] == str(Path(after['service']['WorkingDirectory']) / 'deployment/runtime.yaml')
    identity = ['fc01_entry_version', 'fc01_config_source_path']
    if check == 'inheritance':
        assert {k:v for k,v in before['runtime'].items() if k not in identity} == {
            k:v for k,v in after['runtime'].items() if k not in identity}
    elif check == 'repeat':
        assert before['runtime_sha256'] == after['runtime_sha256']
        assert before['service']['MainPID'] == after['service']['MainPID']
        assert before['processes'] == after['processes']
    elif check == 'rollback':
        for key in ('runtime_sha256', 'runtime', 'controller_sha256', 'source_commit'):
            assert before[key] == after[key], key
        for key in ('ActiveState', 'WorkingDirectory', 'DropInPaths'):
            assert before['service'][key] == after['service'][key], key
    else:
        raise ValueError(check)
    output(check + '-comparison.json', dict(check=check, passed=True, before=a, after=b,
                                            runtime_sha256_before=before['runtime_sha256'],
                                            runtime_sha256_after=after['runtime_sha256'],
                                            controller_before=one_native(before['processes'])['pid'],
                                            controller_after=one_native(after['processes'])['pid'],
                                            inherited_dds=after['environment']))
    print('ARM64_' + check.upper() + '_PASS', a, b, flush=True)


if __name__ == '__main__':
    action, *rest = sys.argv[1:]
    operations = {'snapshot': snapshot, 'monitor': monitor,
                  'check-transition': check_transition, 'compare': compare}
    operations[action](*rest)
