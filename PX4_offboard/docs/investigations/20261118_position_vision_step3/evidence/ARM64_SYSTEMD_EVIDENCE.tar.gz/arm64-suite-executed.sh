#!/usr/bin/env bash
set -euo pipefail
test "$(hostname)" = fc01-arm64-test-vm
test "$(uname -m)" = aarch64
readonly VM_HOME=/home/orangepi
readonly LOG=/root/position-step3-evidence
readonly DESKTOP="$VM_HOME/Desktop/fc01-position-step3"
readonly RELEASE=20261118_position_vision_step3
readonly FIX1=20261118_vision_step6_fix1
readonly ENTRY="$VM_HOME/FC01_versions/$RELEASE"
readonly ARCHIVE="FC01_OrangePi_${RELEASE}_arm64.tar.gz"
readonly SERVICE=fc01-navigation.service
readonly PROBE="$LOG/probe.py"
readonly SITE="$DESKTOP/vm-only-site.json"

user() { runuser -u orangepi -- "$@"; }
snapshot() { python3 -B "$PROBE" snapshot "$@"; }
compare() { python3 -B "$PROBE" compare "$@"; }

cd "$DESKTOP"
sha256sum -c "$ARCHIVE.sha256"
sha256sum -c install_fc01.sh.sha256
printf 'ARM64_SYSTEMD_ENVIRONMENT '
. /etc/os-release
printf '%s %s %s %s\n' "$PRETTY_NAME" "$(uname -m)" "$(uname -r)" "$(systemctl --version | head -1)"
printf 'ARM64_UART_FIXTURE %s\n' "$(readlink /dev/ttyS2)"
cat "$ARCHIVE.sha256" install_fc01.sh.sha256
printf 'ARM64_NO_ATTACHED_CAMERA '
if compgen -G '/dev/video*' || test -e /dev/v4l/by-id/FC01_VM_NO_PHYSICAL_CAMERA; then
  exit 1
fi
printf 'no physical cameras\n'
snapshot before "$FIX1" altitude
python3 -B "$PROBE" monitor &
witness=$!
trap 'kill "$witness" 2>/dev/null || true; wait "$witness" || true' EXIT
printf 'ARM64_ACTIVE_FIX1_TO_FINAL_INSTALL_BEGIN\n'
user bash "$DESKTOP/install_fc01.sh" "$DESKTOP/$ARCHIVE" | tee "$LOG/install.log"
grep -q '^FC01_PREBUILT_INSTALL_OK ' "$LOG/install.log"
grep -q '^FC01_FLIGHT_READINESS=.*"ready_for_manual_rc": false' "$LOG/install.log"
snapshot after-install "$RELEASE" altitude
compare before after-install inheritance
printf 'ARM64_ACTIVE_FIX1_TO_FINAL_INSTALL_PASS\n'

readelf -h "$ENTRY/install/lib/jikl_fc01_system/fc01_system_node" | grep -E 'Class:|Machine:'
(
  set +u
  export PYTHONDONTWRITEBYTECODE=1 ROS_DOMAIN_ID=0 ROS_LOCALHOST_ONLY=0
  source /opt/ros/humble/setup.bash
  source "$ENTRY/install/local_setup.bash"
  python3 -B - "$ENTRY" "$LOG" <<'PY'
import importlib.util
from pathlib import Path
import sys
entry, logs = map(Path, sys.argv[1:])
script = logs / 'generated-check-direct.py'
spec = importlib.util.spec_from_file_location('check', script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.SOURCE_PACKAGE = entry / 'native/src/jikl_fc01_system'
raise SystemExit(module.main(['--prefix', str(entry/'install'), '--report', str(logs/'typesupport.json')]))
PY
)

printf 'ARM64_CONFIGURE_POSITION_BEGIN\n'
user sudo -n systemctl stop "$SERVICE"
user python3 -B "$ENTRY/navigation_vision_mode.py" position --entry "$ENTRY" --maintenance
user sudo -n systemctl start "$SERVICE"
snapshot position "$RELEASE" position
(
  set +u
  export PYTHONDONTWRITEBYTECODE=1 ROS_DOMAIN_ID=0 ROS_LOCALHOST_ONLY=0
  source /opt/ros/humble/setup.bash
  source "$ENTRY/install/local_setup.bash"
  python3 -B "$LOG/observe.py" --seconds 20 --output "$LOG/position-no-feedback-ros.json"
)
printf 'ARM64_CONFIGURE_POSITION_TRACK_BEGIN\n'
python3 -B /root/step6-evidence/fc01-step6-vm-probe.py make-site --output "$SITE"
chown orangepi:orangepi "$SITE"
user sudo -n systemctl stop "$SERVICE"
user python3 -B "$ENTRY/navigation_vision_mode.py" position-track --site "$SITE" --entry "$ENTRY" --maintenance
user sudo -n systemctl start "$SERVICE"
snapshot position-track "$RELEASE" position-track
(
  set +u
  export PYTHONDONTWRITEBYTECODE=1 ROS_DOMAIN_ID=0 ROS_LOCALHOST_ONLY=0
  source /opt/ros/humble/setup.bash
  source "$ENTRY/install/local_setup.bash"
  python3 -B "$LOG/observe.py" --seconds 20 --output "$LOG/position-track-no-feedback-ros.json"
)
user bash "$DESKTOP/install_fc01.sh" --status > "$LOG/installed-status.json"
monitor_rc=0
timeout --preserve-status --signal=INT 5s runuser -u orangepi -- python3 -B "$ENTRY/navigation.py" monitor > "$LOG/monitor.log" || monitor_rc=$?
test "$monitor_rc" = 0 || test "$monitor_rc" = 130
grep -q 'FC01 导航控制' "$LOG/monitor.log"
grep -q '1.5 m' "$LOG/monitor.log"
grep -q 'PX4 位置闭环' "$LOG/monitor.log"
snapshot after-monitor "$RELEASE" position-track
compare position-track after-monitor repeat

printf 'ARM64_FINAL_PACKAGE_REPEAT_BEGIN\n'
user bash "$DESKTOP/install_fc01.sh" "$DESKTOP/$ARCHIVE" | tee "$LOG/repeat-install.log"
grep -q '^FC01_PREBUILT_INSTALL_OK ' "$LOG/repeat-install.log"
grep -q '"already_active": true' "$LOG/repeat-install.log"
snapshot after-repeat "$RELEASE" position-track
compare position-track after-repeat repeat

printf 'ARM64_FINAL_PACKAGE_ROLLBACK_BEGIN\n'
backup=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["backup"])' "$ENTRY/deployment/INSTALL_STATE.json")
user bash "$DESKTOP/install_fc01.sh" --rollback "$backup" | tee "$LOG/rollback.log"
grep -q '^FC01_PREBUILT_ROLLBACK_OK ' "$LOG/rollback.log"
snapshot after-rollback "$FIX1" altitude
compare before after-rollback rollback
python3 -B - "$LOG" "$backup" <<'PYSERVICE'
import hashlib
import json
from pathlib import Path
import sys
log, backup = map(Path, sys.argv[1:])
record = json.loads((backup/'BACKUP.json').read_bytes())
saved = []
for item in record['files']:
    if not item.get('present', True):
        assert not Path(item['path']).exists(), item['path']
    else:
        assert (backup/item['backup']).read_bytes() == Path(item['path']).read_bytes(), item['path']
        saved.append(dict(path=item['path'], sha256=item['sha256']))
before = json.loads((log/'before.json').read_bytes())
assert record['phase'] == 'rolled_back'
assert hashlib.sha256((backup/'runtime.yaml').read_bytes()).hexdigest() == before['runtime_sha256']
(log/'restored-service-files.json').write_text(json.dumps(saved, indent=2)+'\n')
print('ARM64_ROLLBACK_SERVICE_FILES_BYTE_IDENTICAL_PASS', len(saved), flush=True)
PYSERVICE
printf 'ARM64_FINAL_PACKAGE_ROLLBACK_PASS\n'
kill "$witness"
wait "$witness"
trap - EXIT
python3 -B "$PROBE" check-transition
printf 'ARM64_FINAL_PACKAGE_SYSTEMD_LIFECYCLE_PASS\n'
