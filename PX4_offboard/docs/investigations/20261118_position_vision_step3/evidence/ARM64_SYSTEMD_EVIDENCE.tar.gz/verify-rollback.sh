#!/usr/bin/env bash
set -euo pipefail
test "$(hostname)" = fc01-arm64-test-vm
test "$(uname -m)" = aarch64
readonly VM_HOME=/home/orangepi
readonly LOG=/root/position-step3-evidence
readonly DESKTOP="$VM_HOME/Desktop/fc01-position-step3"
readonly RELEASE=20261118_position_vision_step3
readonly FIX1=20261118_vision_step6_fix1
readonly ENTRY="$VM_HOME/FC01_versions/$RELEASE"
readonly ARCHIVE="FC01_OrangePi_${RELEASE}_arm64.tar.gz"
readonly SERVICE=fc01-navigation.service
readonly PROBE="$LOG/probe.py"
readonly SITE="$DESKTOP/vm-only-site.json"

user() { runuser -u orangepi -- "$@"; }
snapshot() { python3 -B "$PROBE" snapshot "$@"; }
compare() { python3 -B "$PROBE" compare "$@"; }

backup=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["backup"])' "$ENTRY/deployment/INSTALL_STATE.json")
grep -qx 'FC01_PREBUILT_ROLLBACK_OK' "$LOG/rollback.log"
snapshot after-rollback "$FIX1" altitude
compare before after-rollback rollback
python3 -B - "$LOG" "$backup" <<'PYSERVICE'
import hashlib
import json
from pathlib import Path
import sys
log, backup = map(Path, sys.argv[1:])
record = json.loads((backup/'BACKUP.json').read_bytes())
saved = []
for item in record['files']:
    if not item.get('present', True):
        assert not Path(item['path']).exists(), item['path']
    else:
        assert (backup/item['backup']).read_bytes() == Path(item['path']).read_bytes(), item['path']
        saved.append(dict(path=item['path'], sha256=item['sha256']))
before = json.loads((log/'before.json').read_bytes())
assert record['phase'] == 'rolled_back'
assert hashlib.sha256((backup/'runtime.yaml').read_bytes()).hexdigest() == before['runtime_sha256']
(log/'restored-service-files.json').write_text(json.dumps(saved, indent=2)+'\n')
print('ARM64_ROLLBACK_SERVICE_FILES_BYTE_IDENTICAL_PASS', len(saved), flush=True)
PYSERVICE
printf 'ARM64_FINAL_PACKAGE_ROLLBACK_PASS\n'
python3 -B "$PROBE" check-transition
printf 'ARM64_FINAL_PACKAGE_SYSTEMD_LIFECYCLE_PASS\n'
