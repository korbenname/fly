#pragma once
#include <cstdint>
#include <functional>
#include <memory>
#include <stdexcept>
#include <string>
#define RCLCPP_ERROR_THROTTLE(logger, clock, interval, ...) ((void)0)
namespace rclcpp {
namespace exceptions {struct RCLError:std::runtime_error {using std::runtime_error::runtime_error;};}
struct Event {
  using SharedPtr=std::shared_ptr<Event>;
  bool value{};
  bool set(){const bool before=value;value=true;return before;}
  bool check() const{return value;}
  bool check_and_clear(){const bool before=value;value=false;return before;}
};
struct Parameter {bool as_bool() const{return false;}};
struct Time {std::int64_t nanoseconds() const{return ::recovery_test_wall_ns;}};
struct Clock {Time now() const{return {};}};
struct MessageInfo {
  struct Rmw {std::int64_t received_timestamp{};struct Gid{unsigned char data[24]{};} publisher_gid;};
  Rmw value{};
  const Rmw& get_rmw_message_info() const{return value;}
};
struct KeepLast {explicit KeepLast(std::size_t){};};
struct QoS {
  explicit QoS(std::size_t){}
  explicit QoS(KeepLast){}
  QoS keep_last(int) const{return *this;}
  QoS reliable() const{return *this;}
  QoS best_effort() const{return *this;}
  QoS durability_volatile() const{return *this;}
};
struct SensorDataQoS:QoS {
  SensorDataQoS():QoS(5){}
  SensorDataQoS keep_last(int) const{return {};}
};
template<class T>struct Subscription {using SharedPtr=std::shared_ptr<Subscription<T>>;};
template<class T>struct Publisher {using SharedPtr=std::shared_ptr<Publisher<T>>;unsigned calls{};T last{};void publish(const T& value){++calls;last=value;};};
class Node {
 public:
  explicit Node(const std::string&){}
  int get_logger() const{return 0;}
  Node* get_node_topics_interface(){return this;}
  std::string resolve_topic_name(const std::string& topic) const{return topic;}
  Parameter get_parameter(const std::string&) const{return {};}
  template<class T>T declare_parameter(const std::string&,const T& value){return value;}
  template<class T,class Qos,class Callback>typename Subscription<T>::SharedPtr create_subscription(const std::string&,Qos,Callback){return std::make_shared<Subscription<T>>();}
  template<class T,class Qos>typename Publisher<T>::SharedPtr create_publisher(const std::string&,Qos){return std::make_shared<Publisher<T>>();}
  std::shared_ptr<Clock> get_clock(){return std::make_shared<Clock>();}
  Event::SharedPtr get_graph_event(){return graph_event;}
  std::size_t count_publishers(const std::string& topic) const{return graph_count?graph_count(topic,true):1;}
  std::size_t count_subscribers(const std::string& topic) const{return graph_count?graph_count(topic,false):1;}
  Event::SharedPtr graph_event{std::make_shared<Event>()};
  std::function<std::size_t(const std::string&,bool)> graph_count;
};
inline void init(int,char**){}
inline void shutdown(){}
inline bool ok(){return false;}
template<class T>void spin_some(const T&){}
namespace executors {
struct SingleThreadedExecutor {
  template<class T>void add_node(const T&){}
  template<class T>void remove_node(const T&){}
  void spin_some(){}
};
}
}
