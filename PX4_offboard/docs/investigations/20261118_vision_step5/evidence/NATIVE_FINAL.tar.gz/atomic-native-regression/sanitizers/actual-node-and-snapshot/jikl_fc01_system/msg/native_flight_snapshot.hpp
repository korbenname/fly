#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include "jikl_fc01_system/msg/stamp.hpp"
#include "jikl_fc01_system/msg/native_flight_state.hpp"
namespace jikl_fc01_system::msg {struct NativeFlightSnapshot{using ConstSharedPtr=std::shared_ptr<const NativeFlightSnapshot>;std::uint16_t schema_version{1};NativeFlightState state;std::array<double,4> attitude_wxyz{};std::string origin_id;std::uint64_t attitude_receive_monotonic_ns{};};}
