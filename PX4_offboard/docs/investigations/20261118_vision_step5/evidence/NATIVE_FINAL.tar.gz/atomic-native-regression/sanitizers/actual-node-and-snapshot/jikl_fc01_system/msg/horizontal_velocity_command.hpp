#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include "jikl_fc01_system/msg/stamp.hpp"
#include "jikl_fc01_system/msg/native_flight_state.hpp"
namespace jikl_fc01_system::msg {struct HorizontalVelocityCommand{using ConstSharedPtr=std::shared_ptr<const HorizontalVelocityCommand>;std::uint16_t schema_version{1};std::uint64_t attitude_sample_stamp_ns{};std::string origin_id;struct Command{std::uint16_t schema_version{2};std::uint64_t sequence{};Stamp stamp;std::uint32_t reset_counter{};std::string source_id,frame_id;bool valid{};double vx{},vy{},vz{},wz{};} command;};}
