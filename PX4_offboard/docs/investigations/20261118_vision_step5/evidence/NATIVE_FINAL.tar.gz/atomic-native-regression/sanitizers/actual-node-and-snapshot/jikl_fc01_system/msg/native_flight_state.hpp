#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include "jikl_fc01_system/msg/stamp.hpp"
#include "jikl_fc01_system/msg/native_flight_state.hpp"
namespace jikl_fc01_system::msg {struct NativeFlightState{using ConstSharedPtr=std::shared_ptr<const NativeFlightState>;std::uint16_t schema_version{1};std::uint64_t sequence{};Stamp stamp;std::string source_id,boot_id,profile,phase,reason;std::uint64_t controller_pid{},task_epoch{},native_monotonic_ns{};bool feedback_current{},publication_current{},ready_wait_arm{},armed{},offboard{},landed{},at_rest{},kill{},operator_takeover{},failsafe{},rc_navigation_enabled{},rc_manual_arm_proven{},ground_reference_valid{},ground_reference_qualified{},liftoff_confirmed{},target_height_settled{},navigation_allowed{};std::uint8_t rc_mode_slot{},rc_navigation_mode_slot{},z_reset_counter{},vz_reset_counter{},quat_reset_counter{};std::uint64_t prestream_commits{},status_stamp_us{},land_stamp_us{},local_stamp_us{},local_sample_stamp_us{},attitude_stamp_us{},attitude_sample_stamp_us{},local_receive_monotonic_ns{};double reference_z_ned{},z_ned{},vz_ned{},relative_height_m{},target_height_m{},height_tolerance_m{},speed_tolerance_mps{},settle_seconds{};};}
