
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main existing_horizontal_regression_main
#include "test_horizontal_navigation.cpp"
#undef main
#pragma GCC diagnostic pop
int main() {
  for (bool tracking : {false,true}) {
    auto in=input();
    if(tracking)velocity(in,{.2,0,0},.2);
    else {in.navigation.valid=true;in.navigation.mode=v::Mode::Cruise;
          in.navigation.position_valid=true;in.navigation.position={.3,0,0};}
    h::Controller controller(config());
    const auto plan=controller.step(in,10,1.5,0,.05);
    need(plan.active&&controller.current(in,10),"valid original plan");
    for (int changed : {0,1}) {
      auto boundary=in;
      if(changed==0)boundary.navigation_publishers=2;
      else boundary.velocity_publishers=2;
      need(!controller.current(boundary,10),"second writer on either channel blocks final sink");
    }
    auto changed=in;
    changed.revocation_generation++;
    need(!controller.current(changed,10),"middle invalid survives healed final payload");
    need(!controller.current(in,10.301),"final check expires original source+receive TTL");
    need(near(controller.last().yaw,plan.yaw),"boundary checks cannot integrate yaw");
  }
  std::cout<<"FINAL_BOUNDARY_EITHER_WRITER_CONFLICT_TTL_REVOCATION_PASS\n";
  auto in=input();velocity(in,{.2,0,0},.3);
  h::Controller controller(config());
  need(controller.step(in,10,1.5,0,.05).active,"tracking starts");
  // 新PX4真实样本不能给不推进sequence的旧指令续鲜。
  in.ros_now_ns=10310000000ULL;
  in.actual.local_stamp_ns=in.actual.attitude_stamp_ns=in.ros_now_ns;
  in.actual.local_received_at=in.actual.attitude_received_at=10.31;
  const auto expired=controller.step(in,10.31,1.5,0,.05);
  need(expired.request_land&&!expired.active,"command timeout while actual fresh descends");
  advance(in,10.36);velocity(in,{.2,0,0},0);
  const auto healthy=controller.step(in,10.36,1.5,0,.05);
  need(healthy.request_land&&!healthy.active,"new healthy frame cannot clear fault");
  std::cout<<"ACTUAL_FRESH_OLD_COMMAND_EXPIRES_AND_CANNOT_SELF_RECOVER_PASS\n";
}
