#pragma once
#include <cstdint>
namespace jikl_fc01_system::msg {struct Stamp{std::int32_t sec{};std::uint32_t nanosec{};template<class T> Stamp& operator=(const T& value){const auto ns=value.nanoseconds();sec=std::int32_t(ns/1000000000);nanosec=std::uint32_t(ns%1000000000);return *this;}};}
