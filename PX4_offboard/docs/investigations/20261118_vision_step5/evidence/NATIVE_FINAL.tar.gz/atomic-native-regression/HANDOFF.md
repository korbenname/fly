# Step5 atomic native snapshot regression handoff

Environment: Ubuntu22.04 x86_64, actual current worktree native source, no hardware/DDS used by this set. HEAD at start 747b9879967fb96fad5953f080b8765a7c9e874f. Current hashes are in FINAL_INPUT_HASHES.json; production node hash 19d20653aea1844e582cc01819da2d0beffe767e1c1b403281070127dee0f0b5.

## Passed against current source

- Fresh `cmake -S native/tests -B /tmp/fc01-step5-atomic-native-regression/native-build -DCMAKE_BUILD_TYPE=Debug`, build, `ctest --test-dir ... --output-on-failure -j4`: **88/88 PASS**. Strict C++17 -Wall/-Wextra/-Werror/-pedantic; assertions enabled.
- `PYTHONPATH=native/tests python3 -m unittest native/tests/test_rc_recovery_adapter.py -v`: **1/1 PASS**, six named checks, including exact same-message raw quaternion/state sample stamp/reset/origin/receive and repeated observation not renewing attitude receive age.
- `python3 native/tests/adapter_compile_check.py`: PASS actual node syntax with minimum API stubs. This does not claim real Humble linkage; root separately built all four Humble packages.
- New Step5 safety edges **2/2 PASS**, five named checks: actual callback duplicates/old/healed revoke, changed same-sequence content, final conflicting writer on either channel, TTL at boundary and fault latch.
- Existing Step4 and Step3 sink differential **1/1 each PASS**, byte-exact all target/heartbeat/command fields and order; 707 control-state samples exact. Step4 baseline 2948bfe4e6a26b5ee58bf02e4e9988e484fad81e, Step3 827f1f4535bc55b1bfa3fc2e97439367af226831.
- Additional same differential with runtime test module BASELINE explicitly set to actual Step5 starting HEAD747b9879967fb96fad5953f080b8765a7c9e874f: **PASS**, 1178 control-sink records /707 state samples. `step5-baseline-sink/RESULT.json`, sink SHA fcabfe83829068353f5eb6c6e4fec08ef5ad503d1cb3af2dd88704e93bf52c5b. This does not mutate repository test baseline.
- Stage2 Core control trace, Runtime/ACK/IPC, publication-policy and partial-sink/order comparison: **3/3 PASS**.
- ASan+UBSan with leak detection: **2/2 standalone instrumented harnesses PASS**: complete actual SystemNode/recovery/snapshot, and final horizontal boundary negative cases. Logs under sanitizers; FINAL_RESULT.json holds final results. g++-11, -O1 -g -fno-omit-frame-pointer -fsanitize=address,undefined; ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1. No diagnostics. CURRENT_FIXTURE_BINDING.json verifies 21 generated fixture inputs and current driver are byte-identical after fixture helper adjustment.

These counts overlap root aggregate Python suites; do not add the same Python methods twice. The extra Step5-baseline invocation is a separate validation, not a newly defined Python test.

## Reproduced test-fixture regression repaired

Native snapshot assertions require Publisher.last. Adding last globally to write_fixture broke existing exact sink instrumentation text. Fixed only native/tests/test_rc_recovery_adapter.py: `write_fixture(root, *, capture_messages=False)` retains prior default contract; the direct snapshot test explicitly uses True. Step3/Step4 sink tests then pass. No production/control behavior changed by this repair.

## Honest failures / explanations

1. The initial snapshot sink run failed before compilation because exact historical Publisher fixture string no longer matched. Original log `/tmp/fc01-step5-atomic-node-tests.log`, copied into this folder as initial-fixture-failure.log. Fixed as above.
2. First complete sanitizer launch failed with `socket directory must be owned and not writable by other users`: evidence folder inherited umask0002. Changing test-only folder to0700 let the *same* instrumented binary pass. Initial run.log/RESULT.json retained; final run-final.log/FINAL_RESULT.json clearly separate. Normal socket safety check is correct, never disabled.
3. Two extra historical Stage2 **full JSON byte** tests against 5198d33 failed because later stages intentionally added 27 diagnostic fields (range evidence, queued safety evidence, stable sample count, px4_horizontal/horizontal metadata). Original tests remain unchanged/FAIL, not counted PASS. Both traces saved under historical-full-json, then independent structural analysis found **all common state fields exact**, no deleted fields, all actual target/heartbeat/command sinks **byte-identical**. Powered trace707 state/1178 sinks; fault/recovery trace1350 state/558 sinks. `EXPLAINED_DIFFERENCES.json` lists every added field and no common-field differences. This supplementary projection does not relabel old full-byte test as passed.

## Boundaries

This evidence proves deterministic host control-output equivalence and sanitizer checks. It does not prove physical flight, ARM64, PX4 firmware adoption, camera hardware timing, ROS delivery or target systemd installation. No source algorithm/config/QoS safety thresholds changed by this verification agent.
