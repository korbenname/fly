#!/bin/bash
set -o pipefail
unset AMENT_PREFIX_PATH CMAKE_PREFIX_PATH COLCON_PREFIX_PATH PYTHONPATH LD_LIBRARY_PATH
source /opt/ros/humble/setup.bash
source /home/jikl62/FC01_R632_P0_ATTITUDE_AUDIT_CANDIDATE/install_r632/px4_msgs/share/px4_msgs/local_setup.bash
source /home/jikl62/.cache/fc01-vision-step4-20261118/install/local_setup.bash
cd /home/jikl62/FC01_OrangePi_Navigation_20261028
out=/tmp/fc01-step5-current-safety
failed=0
for scene in feedback_stale quat_reset vertical_reset offboard_loss offboard_flag rc_takeover kill range_unavailable velocity_warning; do
 /usr/bin/python3 tests/ros_stage3_lifecycle.py --node /home/jikl62/.cache/fc01-vision-step4-20261118/install/jikl_fc01_system/lib/jikl_fc01_system/fc01_system_node --build-evidence docs/investigations/20261118_vision_step4/evidence/ROS_BUILD.json --domain 185 --scenario "$scene" --output "$out/$scene" > "$out/$scene.log" 2>&1
 rc=$?
 printf '%s exit=%s\n' "$scene" "$rc" | tee -a "$out/exits.log"
 if [ "$rc" != 0 ];then failed=1;fi
 done
exit "$failed"
