"""Independent edge checks executing actual Mission callback methods; no ROS/motion."""
import hashlib,json,sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/home/jikl62/FC01_OrangePi_Navigation_20261028')
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from tests.test_mission_pending_alignment import fixture,frame
from tests.test_mission_sensor_contract import platform
checks=[]
# Repeated messages must neither replace waiting frame nor refresh receive stamp.
n=fixture()
with patch('time.monotonic',side_effect=n.now_mono):
 n.platform_history.accept(platform(99_998_000_000,10.),n.now_ns,10.)
 original=frame(n.now_ns,1);n._on_state(original);pending=n.pending_target
 n.now_ns+=100_000_000;n._on_state(original)
 assert n.pending_target is pending and n.pending_target[2]==10.
checks.append('duplicate_preserves_original_pending_receive_stamp')
# Source reset must clear pending; retired source cannot restore it.
n=fixture()
with patch('time.monotonic',side_effect=n.now_mono):
 n.platform_history.accept(platform(99_998_000_000,10.),n.now_ns,10.)
 n._on_state(frame(n.now_ns,1));assert n.pending_target
 n.now_ns+=8_000_000;m=frame(n.now_ns,2);m.source_id='new-camera';n._on_state(m)
 assert n.pending_target is None and n.last_target_sample==0
 n.now_ns+=8_000_000;n._on_state(frame(n.now_ns,3))
 assert n.pending_target is None and n.last_target_sample==0
checks.append('source_reset_clears_pending_and_retired_camera_stays_rejected')
# Expiry after tracking must preserve original fault latch even if new frame is healthy.
n=fixture();n.native_tracking_started=True
with patch('time.monotonic',side_effect=n.now_mono):
 n.platform_history.accept(platform(99_998_000_000,10.),n.now_ns,10.)
 n._on_state(frame(n.now_ns,1));assert n.pending_target
 n.now_ns+=310_000_000;n._consume_pending(n.now_mono())
 assert n.pending_target is None and n.horizontal_fault_reason=='TARGET_PENDING_STALE'
 n.platform_history.accept(platform(n.now_ns,n.now_mono()),n.now_ns,n.now_mono())
 n.now_ns+=8_000_000;n._on_state(frame(n.now_ns,2))
 assert n.horizontal_fault_reason=='TARGET_PENDING_STALE'
checks.append('old_pending_expiry_still_faults_tracking_and_new_frame_does_not_clear_latch')
print(json.dumps(dict(result='PASS',checks=checks,source_sha256=hashlib.sha256((ROOT/'target/src/fc01_mission/fc01_mission/mission_node.py').read_bytes()).hexdigest()),indent=2))
